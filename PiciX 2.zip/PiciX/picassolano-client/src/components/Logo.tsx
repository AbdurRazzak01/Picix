// import logo from "../assets/logo.jpg";

export const Logo = () => {
  return (
    <div style={{ width: "10%" }}>
      <img src='https://res.cloudinary.com/dac48s3os/image/upload/v1710067860/logo_pwlroq.jpg' alt="logo" />
    </div>
  );
};
