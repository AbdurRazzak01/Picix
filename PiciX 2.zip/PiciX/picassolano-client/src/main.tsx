import React from "react";
import ReactDOM from "react-dom";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import App from "./App";
import { Leaderboard } from "./components/Leaderboard";

import "./index.css";
import { UserProvider } from "./hooks/useUser";

import { RadixProvider } from "@radixdlt/react-dapp";
import { RadixIdentityManager } from "@radixdlt/identity";

// Initialize Radix Identity Manager
const identityManager = new RadixIdentityManager();

ReactDOM.render(
  <RadixProvider identityManager={identityManager}>
    <React.StrictMode>
      <UserProvider>
        <Router>
          <Routes>
            <Route path="/" element={<App />} />
            <Route path="/leaderboard" element={<Leaderboard />} />
          </Routes>
        </Router>
      </UserProvider>
    </React.StrictMode>
  </RadixProvider>,
  document.getElementById("root")
);
